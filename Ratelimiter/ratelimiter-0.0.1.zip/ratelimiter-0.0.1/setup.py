
import setuptools

setuptools.setup(
    author='voussoir',
    name='ratelimiter',
    version='0.0.1',
    description='',
    py_modules=['ratelimiter'],
)
