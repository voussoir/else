
import setuptools

setuptools.setup(
    author='voussoir',
    name='voussoirkit',
    version='0.0.1',
    description='',
    py_modules=['voussoirkit.bytestring', 'voussoirkit.clipext', 'voussoirkit.downloady', 'voussoirkit.pathclass', 'voussoirkit.ratelimiter', 'voussoirkit.ratemeter', 'voussoirkit.spinal'],
)
